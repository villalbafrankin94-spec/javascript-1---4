<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TareaController;
use App\Http\Controllers\AuthController;
Route::post('/registro',[AuthController::class,'registro']);
Route::post('/login',[AuthController::class,'login']);
Route::middleware('auth:api')->group(function(){
    Route::get('/perfil',[AuthController::class,'perfil']);
    Route::post('/logout',[AuthController::class,'logout']);
    Route::apiResource('tareas', TareaController::class);
    Route::post('tareas/{id}/completar',[TareaController::class,'completar']);
});
