<?php
namespace Tests\Feature\Api;
use Tests\TestCase;
use App\Models\Tarea;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
class TareaTest extends TestCase {
    use RefreshDatabase;
    /** @test */
    public function usuario_puede_obtener_lista_de_tareas(){
        $user = User::factory()->create();
        Tarea::factory()->count(5)->create(['user_id'=>$user->id]);
        $response = $this->actingAs($user,'api')->getJson('/api/tareas');
        $response->assertStatus(200);
        $response->assertJsonStructure(['data'=>[['id','titulo','descripcion']]]);
    }
}
