<?php
namespace App\Http\Resources;
use Illuminate\Http\Resources\Json\JsonResource;
class TareaResource extends JsonResource {
    public function toArray($request){
        return [
            'id'=>$this->id,
            'titulo'=>$this->titulo,
            'descripcion'=>$this->descripcion,
            'completada'=>$this->completada,
            'fecha_limite'=>$this->fecha_limite?->format('Y-m-d'),
            'created_at'=>$this->created_at->toISOString(),
            'usuario'=>[
                'id'=>$this->usuario->id,
                'nombre'=>$this->usuario->name
            ]
        ];
    }
}
