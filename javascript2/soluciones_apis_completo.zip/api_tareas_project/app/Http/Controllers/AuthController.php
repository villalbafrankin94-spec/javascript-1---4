<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Tymon\JWTAuth\Facades\JWTAuth;
class AuthController extends Controller {
    public function registro(Request $request){
        $validated = $request->validate([
            'name'=>'required|string|max:255',
            'email'=>'required|email|unique:users,email',
            'password'=>'required|string|min:8|confirmed'
        ]);
        $user = User::create(['name'=>$validated['name'],'email'=>$validated['email'],'password'=>Hash::make($validated['password'])]);
        $token = JWTAuth::fromUser($user);
        return response()->json(['access_token'=>$token,'token_type'=>'bearer','expires_in'=>auth('api')->factory()->getTTL()*60,'usuario'=>$user],201);
    }
    public function login(Request $request){
        $cred = $request->only('email','password');
        if(!$token = auth('api')->attempt($cred)){
            return response()->json(['error'=>'Credenciales inválidas'],401);
        }
        return $this->respuestaConToken($token);
    }
    protected function respuestaConToken($token){
        return response()->json(['access_token'=>$token,'token_type'=>'bearer','expires_in'=>auth('api')->factory()->getTTL()*60,'usuario'=>auth('api')->user()]);
    }
    public function perfil(){ return response()->json(auth('api')->user()); }
    public function logout(){ auth('api')->logout(); return response()->json(['mensaje'=>'Sesión cerrada']); }
    public function refresh(){ $token = auth('api')->refresh(); return $this->respuestaConToken($token); }
}
