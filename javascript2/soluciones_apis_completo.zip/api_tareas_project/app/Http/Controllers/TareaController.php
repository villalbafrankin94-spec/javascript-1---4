<?php
namespace App\Http\Controllers;
use App\Models\Tarea;
use Illuminate\Http\Request;
use App\Http\Resources\TareaResource;
class TareaController extends Controller {
    public function index(){
        $tareas = auth()->user()->tareas()->orderBy('created_at','desc')->paginate(15);
        return TareaResource::collection($tareas);
    }
    public function show($id){
        $tarea = Tarea::where('user_id', auth()->id())->findOrFail($id);
        return new TareaResource($tarea);
    }
    public function store(Request $request){
        $validated = $request->validate([
            'titulo'=>'required|string|max:255',
            'descripcion'=>'nullable|string',
            'fecha_limite'=>'nullable|date|after:today'
        ]);
        $validated['user_id'] = auth()->id();
        $tarea = Tarea::create($validated);
        return new TareaResource($tarea);
    }
    public function update(Request $request, $id){
        $tarea = Tarea::where('user_id', auth()->id())->findOrFail($id);
        $validated = $request->validate([
            'titulo'=>'sometimes|required|string|max:255',
            'descripcion'=>'nullable|string',
            'completada'=>'boolean',
            'fecha_limite'=>'nullable|date'
        ]);
        $tarea->update($validated);
        return new TareaResource($tarea);
    }
    public function destroy($id){
        $tarea = Tarea::where('user_id', auth()->id())->findOrFail($id);
        $tarea->delete();
        return response()->json(null,204);
    }
    public function completar($id){
        $tarea = Tarea::where('user_id', auth()->id())->findOrFail($id);
        $tarea->update(['completada'=>true]);
        return new TareaResource($tarea);
    }
}
