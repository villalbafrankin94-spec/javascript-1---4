<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Tarea extends Model {
    protected $fillable = ['user_id','titulo','descripcion','completada','fecha_limite'];
    protected $casts = ['completada'=>'boolean','fecha_limite'=>'date'];
    public function usuario(){ return $this->belongsTo(User::class,'user_id'); }
}
