API de Tareas (Ejercicio 1) - Proyecto de ejemplo
Instrucciones rápidas:
1. Crear proyecto Laravel real: composer create-project laravel/laravel api-tareas
2. Copiar los archivos de 'app/Models', 'app/Http/Controllers', 'database/migrations', 'routes/api.php', 'app/Http/Resources'
3. Instalar JWT: composer require tymon/jwt-auth
   php artisan vendor:publish --provider="Tymon\JWTAuth\Providers\LaravelServiceProvider"
   php artisan jwt:secret
4. Configurar .env (DB_*, JWT_SECRET)
5. Ejecutar migraciones: php artisan migrate
6. Ejecutar tests: php artisan test
