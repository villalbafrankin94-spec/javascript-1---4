<?php
namespace App\Http\Resources;
use Illuminate\Http\Resources\Json\JsonResource;
class ComentarioResource extends JsonResource {
    public function toArray($request){
        return ['id'=>$this->id,'contenido'=>$this->contenido,'usuario'=>['id'=>$this->usuario->id,'nombre'=>$this->usuario->name],'created_at'=>$this->created_at->toISOString()];
    }
}
