<?php
namespace App\Http\Resources;
use Illuminate\Http\Resources\Json\JsonResource;
class ArticuloResource extends JsonResource {
    public function toArray($request){
        return [
            'id'=>$this->id,
            'titulo'=>$this->titulo,
            'slug'=>$this->slug,
            'contenido'=>$this->contenido,
            'imagen'=>$this->imagen,
            'publicado'=>$this->publicado,
            'created_at'=>$this->created_at->toISOString(),
            'usuario'=>['id'=>$this->usuario->id,'nombre'=>$this->usuario->name],
            'comentarios'=>ComentarioResource::collection($this->whenLoaded('comentarios'))
        ];
    }
}
