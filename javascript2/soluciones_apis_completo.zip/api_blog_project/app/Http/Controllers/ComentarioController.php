<?php
namespace App\Http\Controllers;
use App\Models\Comentario;
use Illuminate\Http\Request;
use App\Http\Resources\ComentarioResource;
class ComentarioController extends Controller {
    public function store(Request $request,$articuloId){
        $validated = $request->validate(['contenido'=>'required|string']);
        $validated['user_id'] = auth()->id();
        $validated['articulo_id'] = $articuloId;
        $c = Comentario::create($validated);
        return new ComentarioResource($c);
    }
    public function destroy($id){
        $c = Comentario::where('user_id',auth()->id())->findOrFail($id);
        $c->delete();
        return response()->json(null,204);
    }
}
