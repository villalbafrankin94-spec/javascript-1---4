<?php
namespace App\Http\Controllers;
use App\Models\Articulo;
use Illuminate\Http\Request;
use App\Http\Resources\ArticuloResource;
class ArticuloController extends Controller {
    public function index(){ $articulos = Articulo::with('usuario')->where('publicado',true)->paginate(10); return ArticuloResource::collection($articulos); }
    public function show($id){ $a = Articulo::with('comentarios.usuario')->findOrFail($id); return new ArticuloResource($a); }
    public function store(Request $request){
        $validated = $request->validate(['titulo'=>'required|string|max:255','contenido'=>'required','imagen'=>'nullable|url','publicado'=>'boolean']);
        $validated['user_id'] = auth()->id();
        $validated['slug'] = \Str::slug($validated['titulo']).'-'.time();
        $art = Articulo::create($validated);
        return new ArticuloResource($art);
    }
    public function update(Request $request,$id){
        $art = Articulo::where('user_id',auth()->id())->findOrFail($id);
        $validated = $request->validate(['titulo'=>'sometimes|required|string|max:255','contenido'=>'nullable','imagen'=>'nullable|url','publicado'=>'boolean']);
        $art->update($validated);
        return new ArticuloResource($art);
    }
    public function destroy($id){ $art = Articulo::where('user_id',auth()->id())->findOrFail($id); $art->delete(); return response()->json(null,204); }
}
