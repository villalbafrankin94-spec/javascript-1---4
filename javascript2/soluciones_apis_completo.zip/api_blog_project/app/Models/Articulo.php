<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Articulo extends Model {
    protected $fillable = ['user_id','titulo','slug','contenido','imagen','publicado'];
    protected $casts = ['publicado'=>'boolean'];
    public function usuario(){ return $this->belongsTo(User::class,'user_id'); }
    public function comentarios(){ return $this->hasMany(Comentario::class); }
}
