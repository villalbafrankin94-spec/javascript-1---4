<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Comentario extends Model {
    protected $fillable = ['articulo_id','user_id','contenido'];
    public function articulo(){ return $this->belongsTo(Articulo::class); }
    public function usuario(){ return $this->belongsTo(User::class,'user_id'); }
}
