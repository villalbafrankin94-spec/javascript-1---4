<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ArticuloController;
use App\Http\Controllers\ComentarioController;
Route::get('/articulos',[ArticuloController::class,'index']);
Route::get('/articulos/{id}',[ArticuloController::class,'show']);
Route::middleware('auth:api')->group(function(){
    Route::post('/articulos',[ArticuloController::class,'store']);
    Route::put('/articulos/{id}',[ArticuloController::class,'update']);
    Route::delete('/articulos/{id}',[ArticuloController::class,'destroy']);
    Route::post('/articulos/{id}/comentarios',[ComentarioController::class,'store']);
    Route::delete('/comentarios/{id}',[ComentarioController::class,'destroy']);
});
