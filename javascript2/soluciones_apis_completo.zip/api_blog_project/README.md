API de Blog (Ejercicio 2) - Proyecto de ejemplo
Contiene modelos Articulo y Comentario, controladores, migraciones y resources.
Instrucciones: Similar a api_tareas_project; copiar a proyecto Laravel real y ejecutar migraciones.
