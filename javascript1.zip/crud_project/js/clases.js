export class Gift {
  constructor(id, gift, tipo, tiempo, precio, imagen) {
    this.id = id;
    this.gift = gift;
    this.tipo = tipo;
    this.tiempo = tiempo;
    this.precio = precio;
    this.imagen = imagen;
  }
}
