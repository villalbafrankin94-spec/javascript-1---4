import { Gift } from './clases.js';
import datosIniciales from '../Data/Data.json' assert { type: 'json' };

let datos = Array.isArray(datosIniciales) ? datosIniciales.slice() : [];
let idGiftUpdate = null;

const cuerpoTabla = document.querySelector('#cuerpo-tabla');
const formAgregar = document.querySelector('#form-gift');
const formModal = document.querySelector('#form-modal');

const myModal = new bootstrap.Modal(document.getElementById('modal-gift'));

window.MostrarModal = (id) => {
  idGiftUpdate = id;
  const index = datos.findIndex(item => item.id === id);
  if (index === -1) return;
  document.querySelector('#gift-modal').value = datos[index].gift;
  document.querySelector('#tipo-modal').value = datos[index].tipo;
  document.querySelector('#tiempo-modal').value = datos[index].tiempo;
  document.querySelector('#precio-modal').value = datos[index].precio;
  document.querySelector('#imagen-modal').value = datos[index].imagen || '';
  myModal.show();
};

window.BorrarGift = (id) => {
  const index = datos.findIndex(item => item.id === id);
  if (index === -1) return;
  if (!confirm(`¿Eliminar "${datos[index].gift}"?`)) return;
  datos.splice(index, 1);
  guardarLocal();
  cargarTabla();
};

const cargarTabla = () => {
  cuerpoTabla.innerHTML = '';
  datos.map(item => {
    const fila = document.createElement('tr');
    fila.innerHTML = `
      <td>${item.gift}</td>
      <td>${item.tipo}</td>
      <td>${item.tiempo}</td>
      <td>$${item.precio}</td>
      <td>
        <div class="d-flex gap-2">
          <button class="btn btn-outline-warning" onclick="window.MostrarModal(${item.id})">
            <i class="fas fa-pencil-alt"></i>
          </button>
          <button class="btn btn-outline-danger" onclick="window.BorrarGift(${item.id})">
            <i class="fas fa-times"></i>
          </button>
        </div>
      </td>
    `;
    cuerpoTabla.appendChild(fila);
  });
};

const generarNuevoId = () => {
  return datos.length ? (datos.at(-1).id + 1) : 1;
};

const agregarGift = (e) => {
  e.preventDefault();
  const id = generarNuevoId();
  const gift = document.querySelector('#gift').value.trim();
  const tipo = document.querySelector('#tipo').value.trim();
  const tiempo = document.querySelector('#tiempo').value.trim();
  const precio = Number(document.querySelector('#precio').value) || 0;
  const imagen = document.querySelector('#imagen').value.trim();
  datos.push(new Gift(id, gift, tipo, tiempo, precio, imagen));
  formAgregar.reset();
  guardarLocal();
  cargarTabla();
};

const giftUpdate = (e) => {
  e.preventDefault();
  const index = datos.findIndex(item => item.id === idGiftUpdate);
  if (index === -1) return;
  datos[index].gift = document.querySelector('#gift-modal').value.trim();
  datos[index].tipo = document.querySelector('#tipo-modal').value.trim();
  datos[index].tiempo = document.querySelector('#tiempo-modal').value.trim();
  datos[index].precio = Number(document.querySelector('#precio-modal').value) || 0;
  datos[index].imagen = document.querySelector('#imagen-modal').value.trim();
  guardarLocal();
  cargarTabla();
  myModal.hide();
};

const guardarLocal = () => {
  try {
    localStorage.setItem('misGifts', JSON.stringify(datos));
  } catch (e) {
    console.warn('No se pudo guardar en localStorage', e);
  }
};

const cargarLocal = () => {
  const raw = localStorage.getItem('misGifts');
  if (raw) {
    try {
      datos = JSON.parse(raw);
    } catch (e) {
      console.warn('Error parseando localStorage, usando datos iniciales');
    }
  }
};

formAgregar.addEventListener('submit', agregarGift);
formModal.addEventListener('submit', giftUpdate);

// Inicializar
cargarLocal();
cargarTabla();
