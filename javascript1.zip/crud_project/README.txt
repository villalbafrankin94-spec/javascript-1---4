Proyecto CRUD Vanilla - Solución
Estructura:
- index.html
- js/clases.js
- js/app.js
- Data/Data.json

Cómo usar:
1. Abre index.html en un navegador moderno que soporte módulos ES6.
2. El CRUD funciona en memoria + localStorage.
3. Para restablecer los datos, limpia el localStorage desde las herramientas del navegador.

Nota:
- Este proyecto es una solución funcional basada en la guía proporcionada.
