"""
soluciones_guia_rpg.py
Soluciones a los ejercicios contenidos en:
"Guía Docente para Principiantes Absolutos: Crear tu Primer Juego RPG en Python"
Instructor: Iván Malaver Fierro

Este script agrupa soluciones de:
- Ejercicios guiados (1,2,3)
- Mini-tareas (variables, listas, diccionarios, input, bucles, manejo de errores)
- Funciones de texto, listas y diccionarios avanzados
- Sistema de inventario
- Guardar/Cargar (archivos y JSON)
- Mini-proyecto: creador de guerreros completo (incluye combate por turnos simple)
- Utilidades y demos

Para usar:
    python soluciones_guia_rpg.py
Sigue el menú principal para ejecutar cada ejercicio o parte.
"""

import random
import json
import datetime
import math
import os

# -------------------------
# Util: mostrar_menu (usado por varios ejercicios)
# -------------------------
def mostrar_menu(opciones, titulo="MENÚ"):
    print("\n" + "=" * 60)
    print(f"{titulo.center(60)}")
    print("=" * 60)
    for i, opt in enumerate(opciones, 1):
        print(f"{i}. {opt}")
    while True:
        resp = input("Elige una opción (número): ").strip()
        if resp.isdigit():
            idx = int(resp) - 1
            if 0 <= idx < len(opciones):
                return idx
        print("Entrada inválida. Ingresa el número de la opción.")

# -------------------------
# Ejercicio guiado 1: Crear menú de comida
# -------------------------
def ejercicio_guiado_1():
    comidas = ["Pizza", "Hamburguesa", "Tacos", "Sushi", "Pasta"]
    indice = mostrar_menu(comidas, "ELIGE TU COMIDA FAVORITA")
    comida_favorita = comidas[indice]
    print(f"¡Excelente elección! Elegiste: {comida_favorita}")
    return comida_favorita

# -------------------------
# Ejercicio guiado 2: Sistema de calificaciones
# -------------------------
def calcular_promedio():
    calificaciones = []
    print("\nIngresa 5 calificaciones (0-100):")
    for i in range(5):
        while True:
            try:
                nota = float(input(f"Calificación {i+1} (0-100): ").strip())
                if 0 <= nota <= 100:
                    calificaciones.append(nota)
                    break
                else:
                    print("La nota debe estar entre 0 y 100.")
            except ValueError:
                print("Ingresa un número válido.")
    promedio = sum(calificaciones) / len(calificaciones)
    if promedio >= 90: letra = "A"
    elif promedio >= 80: letra = "B"
    elif promedio >= 70: letra = "C"
    elif promedio >= 60: letra = "D"
    else: letra = "F"
    print(f"Promedio: {promedio:.1f} - Calificación: {letra}")
    return promedio, letra

# -------------------------
# Ejercicio guiado 3: Calculadora de estadísticas RPG
# -------------------------
def calculadora_rpg():
    clases = {
        "Guerrero": {"vida_mult": 10, "ataque_mult": 3, "defensa_mult": 4},
        "Mago": {"vida_mult": 5, "ataque_mult": 6, "defensa_mult": 2},
        "Arquero": {"vida_mult": 7, "ataque_mult": 5, "defensa_mult": 3},
        "Clérigo": {"vida_mult": 8, "ataque_mult": 2, "defensa_mult": 5}
    }
    while True:
        try:
            nivel = int(input("Nivel del personaje (1-50): ").strip())
            if 1 <= nivel <= 50:
                break
            else:
                print("El nivel debe estar entre 1 y 50.")
        except ValueError:
            print("Ingresa un número válido.")
    nombres_clases = list(clases.keys())
    indice = mostrar_menu(nombres_clases, "SELECCIONA LA CLASE")
    clase_elegida = nombres_clases[indice]
    mult = clases[clase_elegida]
    vida = 50 + (nivel * mult["vida_mult"])
    ataque = 10 + (nivel * mult["ataque_mult"])
    defensa = 5 + (nivel * mult["defensa_mult"])
    print(f"\n=== {clase_elegida.upper()} NIVEL {nivel} ===")
    print(f"Vida: {vida}")
    print(f"Ataque: {ataque}")
    print(f"Defensa: {defensa}")
    return {"clase": clase_elegida, "nivel": nivel, "vida": vida, "ataque": ataque, "defensa": defensa}

# -------------------------
# Mini-tareas básicas
# -------------------------
def mini_variables():
    nombre = "TuNombre"
    edad = 20
    comida_fav = "Pizza"
    print(f"Nombre: {nombre}, Edad: {edad}, Comida favorita: {comida_fav}")
    return nombre, edad, comida_fav

def mini_listas():
    peliculas = ["El Laberinto del Fauno", "Interestelar", "Matrix", "El Señor de los Anillos", "Origen"]
    primera = peliculas[0]
    ultima = peliculas[-1]
    print("Primera película:", primera)
    print("Última película:", ultima)
    return peliculas

def mini_diccionarios():
    persona = {"nombre": "Ana", "edad": 25, "ciudad": "Madrid", "hobby": "lectura"}
    print("Nombre:", persona["nombre"])
    print("Edad:", persona["edad"])
    print("Ciudad:", persona["ciudad"])
    print("Hobby:", persona["hobby"])
    return persona

def mini_input_edad():
    nombre = input("Tu nombre: ").strip()
    while True:
        try:
            edad = int(input("Tu edad: ").strip())
            break
        except ValueError:
            print("Ingresa un número válido.")
    ahora = datetime.datetime.now()
    anio_nacimiento = ahora.year - edad
    print(f"Hola {nombre}. Naciste en (aprox): {anio_nacimiento}")
    return nombre, edad, anio_nacimiento

def jugar_adivina_numero():
    secreto = random.randint(1, 10)
    print("Adivina el número entre 1 y 10.")
    intentos = 0
    while True:
        intentos += 1
        try:
            p = int(input("Tu intento: ").strip())
        except ValueError:
            print("Número inválido.")
            continue
        if p == secreto:
            print(f"¡Acertaste en {intentos} intentos!")
            return intentos
        elif p < secreto:
            print("Muy bajo.")
        else:
            print("Muy alto.")

def pedir_edad_segura(mensaje="Ingresa tu edad: "):
    while True:
        try:
            respuesta = input(mensaje).strip()
            if respuesta == "":
                print("No ingresaste nada.")
                continue
            numero = int(respuesta)
            if 1 <= numero <= 120:
                return numero
            else:
                print("La edad debe estar entre 1 y 120.")
        except ValueError:
            print("Ingresa un número válido.")

# -------------------------
# Funciones de texto y utilidades
# -------------------------
def limpiar_nombre(nombre_sucio):
    return nombre_sucio.strip().title()

def es_email_valido(email):
    email = email.strip().lower()
    return "@" in email and "." in email and not email.startswith("@")

def analizar_texto(texto):
    palabras = texto.split()
    return {
        "total_palabras": len(palabras),
        "total_caracteres": len(texto),
        "palabra_mas_larga": max(palabras, key=len) if palabras else ""
    }

# -------------------------
# Trabajo con listas avanzado (inventario)
# -------------------------
def sistema_inventario_demo():
    armas = ["Espada", "Hacha", "Arco"]
    armaduras = ["Casco", "Peto"]
    pociones = ["Poción de Vida", "Poción de Maná"]
    inventario = {"armas": armas.copy(), "armaduras": armaduras.copy(), "pociones": pociones.copy(), "oro": 500}
    print("Inventario inicial:", inventario)
    # usar una poción
    if inventario["pociones"]:
        usada = inventario["pociones"].pop(0)
        print("Usaste:", usada)
    print("Inventario ahora:", inventario)
    return inventario

# -------------------------
# Guardar/Cargar datos (archivos y JSON)
# -------------------------
def guardar_jugador_txt(nombre, nivel, puntos, archivo="jugador.txt"):
    with open(archivo, 'w', encoding='utf-8') as file:
        file.write(f"Nombre: {nombre}\n")
        file.write(f"Nivel: {nivel}\n")
        file.write(f"Puntos: {puntos}\n")
    print(f"Datos de {nombre} guardados en {archivo}")

def cargar_jugador_txt(archivo="jugador.txt"):
    try:
        with open(archivo, 'r', encoding='utf-8') as file:
            lineas = file.readlines()
        datos = {}
        for linea in lineas:
            parts = linea.strip().split(": ", 1)
            if len(parts) == 2:
                clave, valor = parts
                if clave in ["Nivel", "Puntos"]:
                    try:
                        datos[clave] = int(valor)
                    except ValueError:
                        datos[clave] = valor
                else:
                    datos[clave] = valor
        return datos
    except FileNotFoundError:
        print("Archivo no encontrado.")
        return None

def guardar_perfil_jugador_json(jugador, archivo="perfil.json"):
    with open(archivo, "w", encoding="utf-8") as f:
        json.dump(jugador, f, indent=4, ensure_ascii=False)
    print(f"Perfil guardado en {archivo}.")

def cargar_perfil_jugador_json(archivo="perfil.json"):
    try:
        with open(archivo, "r", encoding="utf-8") as f:
            perfil = json.load(f)
        return perfil
    except (FileNotFoundError, json.JSONDecodeError):
        print("No se pudo cargar el perfil.")
        return None

# -------------------------
# Mini-proyecto: Creador de guerreros (con combate simple)
# -------------------------
def crear_guerrero_completo():
    tipos = ["Vikingo", "Caballero", "Samurai", "Mongol", "Romano"]
    armas_por_tipo = {
        "Vikingo": ["Hacha de guerra", "Espada vikinga", "Martillo"],
        "Caballero": ["Espada larga", "Lanza", "Maza"],
        "Samurai": ["Katana", "Wakizashi", "Yumi"],
        "Mongol": ["Arco compuesto", "Lanza mongol"],
        "Romano": ["Gladius", "Pilum", "Espada romana"]
    }
    protecciones = ["Cuero", "Cota de malla", "Placas"]
    nombre = input("Nombre del guerrero: ").strip() or "SinNombre"
    idx_tipo = mostrar_menu(tipos, "ELIGE TIPO")
    tipo = tipos[idx_tipo]
    idx_arma = mostrar_menu(armas_por_tipo[tipo], "ELIGE ARMA")
    arma = armas_por_tipo[tipo][idx_arma]
    idx_prot = mostrar_menu(protecciones, "ELIGE PROTECCIÓN")
    proteccion = protecciones[idx_prot]
    nivel = pedir_edad_segura("Nivel (1-50): ")
    # Stats base y bonificaciones (más completas)
    base = {"vida": 80 + nivel*2, "ataque": 8 + nivel, "defensa": 5 + (nivel//5)}
    bonificaciones_tipo = {
        "Vikingo": {"vida": 20, "ataque": 5},
        "Caballero": {"vida": 25, "ataque": 3},
        "Samurai": {"vida": 15, "ataque": 7},
        "Mongol": {"vida": 10, "ataque": 8},
        "Romano": {"vida": 18, "ataque": 4}
    }
    bonif_arma = {
        "Hacha de guerra": 18, "Espada vikinga": 15, "Martillo": 20,
        "Espada larga": 16, "Lanza": 14, "Maza": 17,
        "Katana": 17, "Wakizashi": 14, "Yumi": 12,
        "Arco compuesto": 15, "Lanza mongol": 13, "Gladius": 14,
        "Pilum": 13, "Espada romana": 15
    }
    bonif_proteccion = {"Cuero": 2, "Cota de malla": 5, "Placas": 8}
    bt = bonificaciones_tipo.get(tipo, {"vida":0,"ataque":0})
    vida = base["vida"] + bt["vida"]
    ataque = base["ataque"] + bt["ataque"] + bonif_arma.get(arma, 10)
    defensa = base["defensa"] + bonif_proteccion.get(proteccion, 0)
    guerrero = {"nombre": nombre, "tipo": tipo, "arma": arma, "proteccion": proteccion, "nivel": nivel, "vida": vida, "ataque": ataque, "defensa": defensa}
    print("\n--- Guerrero creado ---")
    for k,v in guerrero.items():
        print(f"{k.title()}: {v}")
    return guerrero

def sistema_combate_turnos(guerrero, enemigo=None):
    if enemigo is None:
        enemigo = {"nombre": "Lobo feroz", "vida": 60, "ataque": 12, "defensa": 3}
    print(f"\nComienza el combate: {guerrero['nombre']} vs {enemigo['nombre']}")
    turno = 0
    vitas = {"player": guerrero["vida"], "enemigo": enemigo["vida"]}
    while vitas["player"] > 0 and vitas["enemigo"] > 0:
        turno += 1
        print(f"\n--- Turno {turno} ---")
        # jugador ataca
        daño = max(0, guerrero["ataque"] - enemigo["defensa"] + random.randint(-3,3))
        vitas["enemigo"] -= daño
        print(f"{guerrero['nombre']} ataca y hace {daño} de daño. Vida enemigo: {max(0, vitas['enemigo'])}")
        if vitas["enemigo"] <= 0:
            print("¡Has ganado!")
            return "victoria"
        # enemigo ataca
        daño_e = max(0, enemigo["ataque"] - guerrero["defensa"] + random.randint(-3,3))
        vitas["player"] -= daño_e
        print(f"{enemigo['nombre']} ataca y hace {daño_e} de daño. Tu vida: {max(0, vitas['player'])}")
        if vitas["player"] <= 0:
            print("Has sido derrotado.")
            return "derrota"
    return "empate"

# -------------------------
# Menú maestro para ejecutar todas las soluciones
# -------------------------
def menu_principal():
    opciones = [
        "Ejercicio guiado 1 - Menú comida",
        "Ejercicio guiado 2 - Promedio y letra",
        "Ejercicio guiado 3 - Calculadora RPG",
        "Mini: variables",
        "Mini: listas",
        "Mini: diccionarios",
        "Mini: input -> año de nacimiento",
        "Mini: adivina número",
        "Mini: pedir edad segura",
        "Mini: limpiar/analizar texto",
        "Mini: inventario demo",
        "Guardar/Cargar texto y JSON",
        "Mini-proyecto: crear guerrero completo",
        "Mini-proyecto: combate por turnos",
        "Salir"
    ]
    while True:
        idx = mostrar_menu(opciones, "SOLUCIONES - MENÚ PRINCIPAL")
        if idx == 0:
            ejercicio_guiado_1()
        elif idx == 1:
            calcular_promedio()
        elif idx == 2:
            calculadora_rpg()
        elif idx == 3:
            mini_variables()
        elif idx == 4:
            mini_listas()
        elif idx == 5:
            mini_diccionarios()
        elif idx == 6:
            mini_input_edad()
        elif idx == 7:
            jugar_adivina_numero()
        elif idx == 8:
            edad = pedir_edad_segura(); print("Edad válida:", edad)
        elif idx == 9:
            nombre = input("Escribe nombre sucio: "); print("Limpio:", limpiar_nombre(nombre)); txt = input("Texto para analizar: "); print(analizar_texto(txt))
        elif idx == 10:
            sistema_inventario_demo()
        elif idx == 11:
            perfil = {"nombre": "Demo", "nivel": 5, "vida": 120}
            guardar_perfil_jugador_json(perfil)
            loaded = cargar_perfil_jugador_json(); print("Cargado:", loaded)
        elif idx == 12:
            g = crear_guerrero_completo()
        elif idx == 13:
            # si no hay guerrero, crear uno rápido
            g = {"nombre": "Hero", "vida": 120, "ataque": 30, "defensa": 8}
            sistema_combate_turnos(g)
        else:
            print("Adiós!")
            break

if __name__ == "__main__":
    menu_principal()
