const db = require('../db');
async function createTask({ user_id, title, description, due_date }){
  const q = 'INSERT INTO tasks (user_id,title,description,due_date) VALUES ($1,$2,$3,$4) RETURNING *';
  const r = await db.query(q, [user_id,title,description,due_date]);
  return r.rows[0];
}
async function getTasksByUser(user_id){ const r = await db.query('SELECT * FROM tasks WHERE user_id=$1 ORDER BY created_at DESC', [user_id]); return r.rows; }
async function getTaskById(id,user_id){ const r = await db.query('SELECT * FROM tasks WHERE id=$1 AND user_id=$2', [id,user_id]); return r.rows[0]; }
async function updateTask(id,user_id,data){ const fields = []; const vals = []; let idx=1; for(const k in data){ fields.push(k+`=$${idx}`); vals.push(data[k]); idx++; } vals.push(id); vals.push(user_id); const q = `UPDATE tasks SET ${fields.join(',')} WHERE id=$${idx} AND user_id=$${idx+1} RETURNING *`; const r = await db.query(q, vals); return r.rows[0]; }
async function deleteTask(id,user_id){ const r = await db.query('DELETE FROM tasks WHERE id=$1 AND user_id=$2 RETURNING *', [id,user_id]); return r.rows[0]; }
module.exports = { createTask, getTasksByUser, getTaskById, updateTask, deleteTask };