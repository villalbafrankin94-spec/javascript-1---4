const Joi = require('joi');
const taskModel = require('../models/taskModel');
const schema = Joi.object({ title: Joi.string().min(3).required(), description: Joi.string().allow('',null), due_date: Joi.date().optional() });
async function getAll(req,res,next){
  try{
    const tasks = await taskModel.getTasksByUser(req.user.id);
    res.json({ tasks });
  }catch(e){ next(e); }
}
async function create(req,res,next){
  try{
    const { error, value } = schema.validate(req.body);
    if(error) return res.status(400).json({ error: error.details.map(d=>d.message) });
    const t = await taskModel.createTask({ user_id: req.user.id, title: value.title, description: value.description, due_date: value.due_date });
    res.status(201).json({ task: t });
  }catch(e){ next(e); }
}
async function getById(req,res,next){
  try{
    const id = parseInt(req.params.id);
    const t = await taskModel.getTaskById(id, req.user.id);
    if(!t) return res.status(404).json({ error: 'Not found' });
    res.json({ task: t });
  }catch(e){ next(e); }
}
async function update(req,res,next){
  try{
    const id = parseInt(req.params.id);
    const { error, value } = schema.validate(req.body);
    if(error) return res.status(400).json({ error: error.details.map(d=>d.message) });
    const updated = await taskModel.updateTask(id, req.user.id, value);
    if(!updated) return res.status(404).json({ error: 'Not found or no permission' });
    res.json({ task: updated });
  }catch(e){ next(e); }
}
async function remove(req,res,next){
  try{
    const id = parseInt(req.params.id);
    const deleted = await taskModel.deleteTask(id, req.user.id);
    if(!deleted) return res.status(404).json({ error: 'Not found or no permission' });
    res.json({ task: deleted });
  }catch(e){ next(e); }
}
module.exports = { getAll, create, getById, update, remove };