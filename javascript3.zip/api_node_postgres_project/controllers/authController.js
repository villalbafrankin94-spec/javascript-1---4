const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const Joi = require('joi');
const userModel = require('../models/userModel');
const schemaRegister = Joi.object({ name: Joi.string().min(2).required(), email: Joi.string().email().required(), password: Joi.string().min(6).required() });
const schemaLogin = Joi.object({ email: Joi.string().email().required(), password: Joi.string().required() });
async function register(req,res,next){
  try{
    const { error, value } = schemaRegister.validate(req.body);
    if(error) return res.status(400).json({ error: error.details.map(d=>d.message) });
    const exists = await userModel.findByEmail(value.email);
    if(exists) return res.status(400).json({ error: 'Email already registered' });
    const hash = await bcrypt.hash(value.password, 10);
    const user = await userModel.createUser({ name: value.name, email: value.email, password: hash });
    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET || 'secret', { expiresIn: '7d' });
    res.status(201).json({ user, token });
  }catch(e){ next(e); }
}
async function login(req,res,next){
  try{
    const { error, value } = schemaLogin.validate(req.body);
    if(error) return res.status(400).json({ error: error.details.map(d=>d.message) });
    const user = await userModel.findByEmail(value.email);
    if(!user) return res.status(400).json({ error: 'Invalid credentials' });
    const ok = await bcrypt.compare(value.password, user.password);
    if(!ok) return res.status(400).json({ error: 'Invalid credentials' });
    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET || 'secret', { expiresIn: '7d' });
    res.json({ user: { id: user.id, name: user.name, email: user.email }, token });
  }catch(e){ next(e); }
}
module.exports = { register, login };