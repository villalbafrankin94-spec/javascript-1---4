const jwt = require('jsonwebtoken');
const userModel = require('../models/userModel');
module.exports = async (req,res,next)=>{
  try{
    const auth = req.headers.authorization;
    if(!auth) return res.status(401).json({ error: 'Token required' });
    const parts = auth.split(' ');
    const token = parts.length===2?parts[1]:parts[0];
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'secret');
    const user = await userModel.findById(decoded.id);
    if(!user) return res.status(401).json({ error: 'Invalid token' });
    req.user = user;
    next();
  }catch(e){ return res.status(401).json({ error: 'Invalid token' }); }
};