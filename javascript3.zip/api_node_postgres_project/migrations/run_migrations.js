const fs = require('fs');
const path = require('path');
const db = require('../db');
(async () => {
  try {
    const dir = path.join(__dirname);
    const files = fs.readdirSync(dir).filter(f => f.endsWith('.sql')).sort();
    for (const file of files) {
      const sql = fs.readFileSync(path.join(dir, file), 'utf8');
      console.log('Ejecutando:', file);
      await db.query(sql);
    }
    console.log('Migraciones ejecutadas.');
    process.exit(0);
  } catch (e) {
    console.error('Error en migraciones:', e);
    process.exit(1);
  }
})();