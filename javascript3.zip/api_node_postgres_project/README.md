API REST - Node.js + Express + PostgreSQL
Contenido del paquete:
- app.js               : punto de entrada
- db/index.js          : cliente PostgreSQL (pg Pool)
- routes/*.js          : definicion de rutas (auth, tasks, users)
- controllers/*.js     : logica de endpoints
- models/*.js          : consultas SQL y funciones hacia BD
- migrations/*.sql     : scripts de creación de tablas
- .env.example         : variables de entorno
- README.md            : este archivo

Pasos para ejecutar (en tu máquina):
1. Instala dependencias: npm install
2. Crea la base de datos PostgreSQL y actualiza DATABASE_URL en .env
3. Ejecuta las migraciones: node migrations/run_migrations.js
4. Inicia el servidor: npm run dev
5. Prueba endpoints en http://localhost:3000

Nota: El proyecto usa autenticación JWT en /api/auth, y recursos protegidos para /api/tasks.
