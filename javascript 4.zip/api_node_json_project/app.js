const express = require('express');
const fs = require('fs');
const cors = require('cors');
const helmet = require('helmet');
const app = express();
app.use(express.json());
app.use(cors());
app.use(helmet());
const PORT = 3000;

function loadDB(){
  return JSON.parse(fs.readFileSync('./data.json'));
}
function saveDB(db){
  fs.writeFileSync('./data.json', JSON.stringify(db,null,2));
}

app.get('/', (req,res)=> res.json({msg:'API JSON lista'}));

app.get('/books', (req,res)=>{
  const db = loadDB();
  res.json(db.books);
});

app.post('/books', (req,res)=>{
  const db = loadDB();
  const newBook = { id: Date.now(), title: req.body.title, author: req.body.author };
  db.books.push(newBook);
  saveDB(db);
  res.status(201).json(newBook);
});

app.put('/books/:id', (req,res)=>{
  const db = loadDB();
  const id = parseInt(req.params.id);
  const idx = db.books.findIndex(b=>b.id===id);
  if(idx<0) return res.status(404).json({error:'Not found'});
  db.books[idx].title = req.body.title;
  db.books[idx].author = req.body.author;
  saveDB(db);
  res.json(db.books[idx]);
});

app.delete('/books/:id', (req,res)=>{
  const db = loadDB();
  const id = parseInt(req.params.id);
  const idx = db.books.findIndex(b=>b.id===id);
  if(idx<0) return res.status(404).json({error:'Not found'});
  const deleted = db.books.splice(idx,1)[0];
  saveDB(db);
  res.json(deleted);
});

app.listen(PORT, ()=> console.log('Servidor JSON en puerto',PORT));
